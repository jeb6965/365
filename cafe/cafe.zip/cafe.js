// Name
"use strict";
//This function is used to retrieve item information when an image is clicked. It will be used later.
const getData = src => {
    let selected = [];
    if (src == "images/biscotti.jpg")
        selected = [1.95, "Biscotti"];
    else if (src == "images/cappuccino.jpg")
        selected = [3.45, "Cappuccino"];
    else if (src == "images/coffee.jpg")
        selected = [1.75, "Coffee"];
    else if (src == "images/espresso.jpg")
        selected = [1.95, "Espresso"];
    else if (src == "images/latte.jpg")
        selected = [2.95, "Latte"];
    else if (src == "images/scone.jpg")
        selected = [2.95, "Scone"];
    return selected;
}
